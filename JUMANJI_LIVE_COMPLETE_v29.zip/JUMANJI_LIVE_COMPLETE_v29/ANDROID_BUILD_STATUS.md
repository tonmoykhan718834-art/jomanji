# Android Build Status — v27

- Added AndroidX WebKit `WebViewAssetLoader` and moved the bundled HTML from a `file://` origin to `https://appassets.androidplatform.net/assets/index.html`. This is a targeted improvement because WebRTC microphone access generally requires a secure origin.
- File access, content access, and mixed content remain disabled. Android runtime microphone permission is still required.
- Android version is now `0.3.0` (versionCode 3).
- Static JavaScript checks and ZIP integrity can be checked locally; this workspace does not have a verified APK build environment, and no APK is included.
- LiveKit microphone functionality still requires Gradle build plus physical-device testing. Google/Facebook/phone authentication, bKash payment, real cash-out, push notifications, and several room/game features are not production-ready.


## v29 note
Fixed saved API URL precedence and bumped Android version to 0.3.1. APK build has not been run in this environment; use the included GitHub Actions workflow or Android Studio and inspect any build errors.
