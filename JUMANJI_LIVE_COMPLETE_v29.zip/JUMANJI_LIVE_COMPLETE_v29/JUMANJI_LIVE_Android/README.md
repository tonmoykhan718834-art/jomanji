# JUMANJI LIVE — Android starter + backend API (v27)

Read the root `SETUP_GUIDE_BN.md` for setup steps. This folder contains the Node.js backend, PostgreSQL schema, Docker Compose setup, and Android WebView app.

## Android app changes in v27
- Bundled HTML is served through AndroidX WebKit `WebViewAssetLoader` at `https://appassets.androidplatform.net/assets/index.html` rather than a `file://` URL.
- File/content access stays disabled, mixed content stays blocked, and microphone requests are gated by Android's runtime permission.
- This is a security/compatibility improvement for the WebView app; it does not prove that LiveKit audio works on every phone.

## Build
Open this folder in Android Studio and allow Gradle Sync. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The GitHub Actions workflow can also attempt a debug build. This package is source code, not a compiled APK.

## Backend quick start
1. Copy `.env.example` to `.env` and replace all sample secrets.
2. Run `docker compose up --build -d`.
3. Check `http://localhost:3000/health` from the host.
4. Run `npm run test:static`; run `npm run test:smoke` only when the backend and database are configured and reachable.

Never commit `.env`, database credentials, JWT secrets, LiveKit API secrets, or signing keys. Rotate any secret previously shared in chat. Payments, cash-outs, social/phone auth, push notifications, and complete production room features are not implemented as live services.


### v29 update
The app now prioritizes the backend API URL saved in Settings after a restart, avoiding the default emulator URL overriding a deployed backend address. Android version: 0.3.1. APK generation and real-device testing are still required.
