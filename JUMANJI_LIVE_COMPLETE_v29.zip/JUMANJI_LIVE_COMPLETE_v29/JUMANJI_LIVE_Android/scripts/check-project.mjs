import { readFile, access, mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';

const root = new URL('../', import.meta.url);
const file = async (path) => readFile(new URL(path, root), 'utf8');
const required = [
  'server.js', 'schema.sql', 'package.json',
  'app/src/main/AndroidManifest.xml',
  'app/src/main/java/com/jumanjilive/app/MainActivity.java',
  'app/src/main/assets/index.html',
  'migrations/014_private_messages.sql',
  'migrations/018_community_admin_rewards.sql',
];
for (const path of required) await access(new URL(path, root));
console.log(`Required project files: OK (${required.length})`);

const server = await file('server.js');
if (!server.includes("app.get('/health'") && !server.includes('app.get("/health"')) {
  throw new Error('Health endpoint declaration not found in server.js');
}
const html = await file('app/src/main/assets/index.html');
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)].map(m => m[1]).filter(s => s.trim());
if (!scripts.length) throw new Error('No inline JavaScript found in index.html');
const temp = await mkdtemp(join(tmpdir(), 'jumanji-static-'));
try {
  const serverPath = join(temp, 'server.mjs');
  await writeFile(serverPath, server);
  const serverCheck = spawnSync(process.execPath, ['--check', serverPath], { encoding: 'utf8' });
  if (serverCheck.status !== 0) throw new Error(`server.js syntax check failed:\n${serverCheck.stderr}`);
  for (let i = 0; i < scripts.length; i++) {
    const scriptPath = join(temp, `inline-${i}.js`);
    await writeFile(scriptPath, scripts[i]);
    const check = spawnSync(process.execPath, ['--check', scriptPath], { encoding: 'utf8' });
    if (check.status !== 0) throw new Error(`index.html inline script ${i + 1} syntax check failed:\n${check.stderr}`);
  }
} finally {
  await rm(temp, { recursive: true, force: true });
}
console.log('Backend JavaScript syntax: OK');
console.log(`HTML inline JavaScript syntax: OK (${scripts.length} script block(s))`);
console.log('Static checks passed. This does not replace database, LiveKit, Gradle, or device testing.');
