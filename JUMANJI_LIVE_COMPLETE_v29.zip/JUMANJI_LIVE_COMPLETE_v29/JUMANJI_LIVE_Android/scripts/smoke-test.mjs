const base = (process.env.API_BASE_URL || 'http://localhost:3000').replace(/\/$/, '');
const unique = `${Date.now()}-${Math.random().toString(16).slice(2,8)}`;
const email = `setup-test-${unique}@example.com`;
const password = `Jumanji-Test-${unique}-!`;
async function call(path, options = {}) {
  const response = await fetch(`${base}${path}`, {
    ...options,
    headers: { 'content-type': 'application/json', ...(options.headers || {}) }
  });
  const text = await response.text();
  let data; try { data = JSON.parse(text); } catch { data = text; }
  if (!response.ok) throw new Error(`${path} -> HTTP ${response.status}: ${JSON.stringify(data)}`);
  return data;
}
try {
  const health = await call('/health');
  console.log('Health:', health);
  if (!health.authConfigured) throw new Error('API is reachable, but DATABASE_URL/JWT_SECRET are not configured.');
  const registered = await call('/api/auth/register', { method: 'POST', body: JSON.stringify({ displayName: 'Setup Test', email, password }) });
  if (!registered.token) throw new Error('Register succeeded but no token returned.');
  const me = await call('/api/auth/me', { headers: { authorization: `Bearer ${registered.token}` } });
  console.log('Register + authenticated /me: OK', me.user?.displayName || 'user');
  console.log('Smoke test passed. Test account email:', email);
} catch (err) {
  console.error('Smoke test failed:', err.message);
  process.exitCode = 1;
}
