import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pg from 'pg';
import { AccessToken } from 'livekit-server-sdk';

const { Pool } = pg;
const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || 'http://localhost:8080' }));
app.use(express.json({ limit: '20kb' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));

const pool = process.env.DATABASE_URL ? new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: false } : undefined }) : null;
const jwtSecret = process.env.JWT_SECRET;
const dbReady = () => Boolean(pool && jwtSecret && jwtSecret.length >= 32);
const safeUser = (u) => ({ id: u.id, displayName: u.display_name, email: u.email, createdAt: u.created_at });
const authRequired = (req, res, next) => { if (!dbReady()) return res.status(503).json({ error: 'Database and authentication are not configured.' }); return requireAuth(req, res, next); };

app.get('/health', (_req, res) => res.json({ ok: true, app: 'JUMANJI LIVE', authConfigured: dbReady() }));

app.post('/api/auth/register', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Authentication is not configured on the server yet.' });
  const displayName = String(req.body?.displayName || '').trim();
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (displayName.length < 2 || displayName.length > 50) return res.status(400).json({ error: 'Display name must be 2–50 characters.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 10 || password.length > 128) return res.status(400).json({ error: 'Password must be 10–128 characters.' });
  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const result = await pool.query('INSERT INTO users (display_name, email, password_hash) VALUES ($1, $2, $3) RETURNING id, display_name, email, created_at', [displayName, email, passwordHash]);
    const user = result.rows[0];
    await pool.query('INSERT INTO wallets (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING', [user.id]);
    const token = jwt.sign({ sub: user.id }, jwtSecret, { expiresIn: '2h', issuer: 'jumanji-live' });
    return res.status(201).json({ user: safeUser(user), token });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'An account with this email already exists.' });
    console.error('Registration failed:', e.message);
    return res.status(500).json({ error: 'Could not create account.' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Authentication is not configured on the server yet.' });
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });
  try {
    const result = await pool.query('SELECT id, display_name, email, password_hash, created_at FROM users WHERE email = $1', [email]);
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'Email or password is incorrect.' });
    await pool.query('INSERT INTO wallets (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING', [user.id]);
    const token = jwt.sign({ sub: user.id }, jwtSecret, { expiresIn: '2h', issuer: 'jumanji-live' });
    return res.json({ user: safeUser(user), token });
  } catch (e) {
    console.error('Login failed:', e.message);
    return res.status(500).json({ error: 'Could not sign in.' });
  }
});

async function requireAuth(req, res, next) {
  const token = req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : '';
  if (!token || !jwtSecret) return res.status(401).json({ error: 'Sign in required.' });
  try {
    const payload = jwt.verify(token, jwtSecret, { issuer: 'jumanji-live' });
    const result = await pool.query('SELECT id, display_name, email, created_at FROM users WHERE id = $1', [payload.sub]);
    if (!result.rows[0]) return res.status(401).json({ error: 'Account not found.' });
    req.user = result.rows[0];
    next();
  } catch { return res.status(401).json({ error: 'Session expired or invalid.' }); }
}

app.get('/api/auth/me', async (req, res, next) => {
  if (!dbReady()) return res.status(503).json({ error: 'Authentication is not configured on the server yet.' });
  return requireAuth(req, res, next);
}, (req, res) => res.json({ user: safeUser(req.user) }));

app.patch('/api/profile', async (req, res, next) => {
  if (!dbReady()) return res.status(503).json({ error: 'Database and authentication are not configured.' });
  return requireAuth(req, res, async () => {
    const displayName = String(req.body?.displayName || '').trim();
    if (displayName.length < 2 || displayName.length > 50) return res.status(400).json({ error: 'Display name must be 2–50 characters.' });
    try {
      const result = await pool.query('UPDATE users SET display_name = $1 WHERE id = $2 RETURNING id, display_name, email, created_at', [displayName, req.user.id]);
      return res.json({ user: safeUser(result.rows[0]) });
    } catch (e) { console.error('Profile update failed:', e.message); return res.status(500).json({ error: 'Could not update profile.' }); }
  });
});

// Persistent room directory and owner-controlled room settings.
app.get('/api/rooms', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room service is not configured on the server.' });
  try {
    const result = await pool.query(`SELECT r.id, r.name, r.description, r.max_seats, r.chat_enabled, r.mic_seats_open, r.created_at, u.display_name AS owner_name,
      (SELECT COUNT(*)::int FROM room_members m WHERE m.room_id = r.id AND m.left_at IS NULL) AS participant_count
      FROM rooms r JOIN users u ON u.id = r.owner_id WHERE r.is_active = TRUE ORDER BY r.created_at DESC LIMIT 100`);
    return res.json({ rooms: result.rows.map(r => ({ id: String(r.id), name: r.name, description: r.description, maxSeats: r.max_seats, chatEnabled: r.chat_enabled, micSeatsOpen: r.mic_seats_open, ownerName: r.owner_name, participantCount: r.participant_count, createdAt: r.created_at })) });
  } catch (e) { console.error('Room list failed:', e.message); return res.status(500).json({ error: 'Could not load rooms.' }); }
});

app.post('/api/rooms', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room service is not configured on the server.' });
  return requireAuth(req, res, async () => {
    const name = String(req.body?.name || '').trim();
    const description = String(req.body?.description || '').trim();
    const maxSeats = Number(req.body?.maxSeats ?? 8);
    if (name.length < 2 || name.length > 70) return res.status(400).json({ error: 'Room name must be 2–70 characters.' });
    if (description.length > 240) return res.status(400).json({ error: 'Description must be at most 240 characters.' });
    if (!Number.isInteger(maxSeats) || maxSeats < 2 || maxSeats > 16) return res.status(400).json({ error: 'maxSeats must be between 2 and 16.' });
    try {
      const result = await pool.query(`INSERT INTO rooms (owner_id, name, description, max_seats) VALUES ($1, $2, $3, $4)
        RETURNING id, name, description, max_seats, chat_enabled, mic_seats_open, created_at`, [req.user.id, name, description, maxSeats]);
      const r = result.rows[0];
      return res.status(201).json({ room: { id: String(r.id), name: r.name, description: r.description, maxSeats: r.max_seats, chatEnabled: r.chat_enabled, micSeatsOpen: r.mic_seats_open, createdAt: r.created_at } });
    } catch (e) { console.error('Room create failed:', e.message); return res.status(500).json({ error: 'Could not create room.' }); }
  });
});

// Join/leave membership and issue room-scoped LiveKit tokens.
async function createRoomToken(user, room, canPublish) {
  if (!process.env.LIVEKIT_API_KEY || !process.env.LIVEKIT_API_SECRET || !process.env.LIVEKIT_URL) {
    const error = new Error('LiveKit credentials are not configured.'); error.status = 503; throw error;
  }
  const livekitRoom = `jumanji-room-${room.id}`;
  const token = new AccessToken(process.env.LIVEKIT_API_KEY, process.env.LIVEKIT_API_SECRET, {
    identity: String(user.id), ttl: '1h', name: user.display_name
  });
  token.addGrant({ roomJoin: true, room: livekitRoom, canPublish, canSubscribe: true });
  return { token: await token.toJwt(), url: process.env.LIVEKIT_URL, livekitRoom, canPublish };
}

app.post('/api/rooms/:roomId/join', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room service is not configured on the server.' });
  return requireAuth(req, res, async () => {
    if (!/^\d{1,18}$/.test(String(req.params.roomId))) return res.status(400).json({ error: 'Invalid room ID.' });
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const found = await client.query('SELECT id, owner_id, name, description, max_seats, chat_enabled, mic_seats_open FROM rooms WHERE id = $1 AND is_active = TRUE FOR UPDATE', [req.params.roomId]);
      const room = found.rows[0];
      if (!room) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Room not found or inactive.' }); }
      const active = await client.query('SELECT 1 FROM room_members WHERE room_id = $1 AND user_id = $2 AND left_at IS NULL LIMIT 1', [room.id, req.user.id]);
      if (!active.rows.length) {
        const count = await client.query('SELECT COUNT(*)::int AS n FROM room_members WHERE room_id = $1 AND left_at IS NULL', [room.id]);
        if (count.rows[0].n >= room.max_seats) { await client.query('ROLLBACK'); return res.status(409).json({ error: 'This room is full.' }); }
        await client.query('INSERT INTO room_members (room_id, user_id) VALUES ($1, $2)', [room.id, req.user.id]);
      }
      await client.query('COMMIT');
      const seatCheck = await pool.query('SELECT mic_seat FROM room_members WHERE room_id = $1 AND user_id = $2 AND left_at IS NULL ORDER BY joined_at DESC LIMIT 1', [room.id, req.user.id]);
      const canPublish = String(room.owner_id) === String(req.user.id) || seatCheck.rows[0]?.mic_seat != null;
      const livekit = await createRoomToken(req.user, room, canPublish);
      return res.json({ room: { id: String(room.id), name: room.name, description: room.description, maxSeats: room.max_seats, chatEnabled: room.chat_enabled }, ...livekit });
    } catch (e) {
      await client.query('ROLLBACK').catch(() => {});
      if (e.status) return res.status(e.status).json({ error: e.message });
      console.error('Room join failed:', e.message); return res.status(500).json({ error: 'Could not join room.' });
    } finally { client.release(); }
  });
});

app.post('/api/rooms/:roomId/leave', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room service is not configured on the server.' });
  return requireAuth(req, res, async () => {
    if (!/^\d{1,18}$/.test(String(req.params.roomId))) return res.status(400).json({ error: 'Invalid room ID.' });
    try {
      const result = await pool.query('UPDATE room_members SET left_at = NOW(), mic_seat = NULL WHERE room_id = $1 AND user_id = $2 AND left_at IS NULL RETURNING room_id', [req.params.roomId, req.user.id]);
      if (!result.rowCount) return res.status(404).json({ error: 'You are not an active member of this room.' });
      return res.json({ ok: true, roomId: String(req.params.roomId), message: 'You left the room. Disconnect from LiveKit on the device too.' });
    } catch (e) { console.error('Room leave failed:', e.message); return res.status(500).json({ error: 'Could not leave room.' }); }
  });
});

app.patch('/api/rooms/:roomId/settings', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room service is not configured on the server.' });
  return requireAuth(req, res, async () => {
    if (!/^\d{1,18}$/.test(String(req.params.roomId))) return res.status(400).json({ error: 'Invalid room ID.' });
    const allowed = ['name', 'description', 'maxSeats', 'chatEnabled', 'micSeatsOpen'];
    const provided = allowed.filter(k => Object.hasOwn(req.body || {}, k));
    if (!provided.length) return res.status(400).json({ error: 'Provide at least one setting to update.' });
    const name = req.body.name === undefined ? undefined : String(req.body.name).trim();
    const description = req.body.description === undefined ? undefined : String(req.body.description).trim();
    const maxSeats = req.body.maxSeats === undefined ? undefined : Number(req.body.maxSeats);
    if (name !== undefined && (name.length < 2 || name.length > 70)) return res.status(400).json({ error: 'Room name must be 2–70 characters.' });
    if (description !== undefined && description.length > 240) return res.status(400).json({ error: 'Description must be at most 240 characters.' });
    if (maxSeats !== undefined && (!Number.isInteger(maxSeats) || maxSeats < 2 || maxSeats > 16)) return res.status(400).json({ error: 'maxSeats must be between 2 and 16.' });
    if (req.body.chatEnabled !== undefined && typeof req.body.chatEnabled !== 'boolean') return res.status(400).json({ error: 'chatEnabled must be true or false.' });
    if (req.body.micSeatsOpen !== undefined && typeof req.body.micSeatsOpen !== 'boolean') return res.status(400).json({ error: 'micSeatsOpen must be true or false.' });
    try {
      const result = await pool.query(`UPDATE rooms SET
        name = COALESCE($1, name), description = COALESCE($2, description), max_seats = COALESCE($3, max_seats),
        chat_enabled = COALESCE($4, chat_enabled), mic_seats_open = COALESCE($5, mic_seats_open), updated_at = NOW()
        WHERE id = $6 AND owner_id = $7 AND is_active = TRUE
        RETURNING id, name, description, max_seats, chat_enabled, mic_seats_open, updated_at`,
        [name ?? null, description ?? null, maxSeats ?? null, req.body.chatEnabled ?? null, req.body.micSeatsOpen ?? null, req.params.roomId, req.user.id]);
      if (!result.rows[0]) return res.status(404).json({ error: 'Room not found or you are not its owner.' });
      const r = result.rows[0];
      return res.json({ room: { id: String(r.id), name: r.name, description: r.description, maxSeats: r.max_seats, chatEnabled: r.chat_enabled, micSeatsOpen: r.mic_seats_open, updatedAt: r.updated_at } });
    } catch (e) { console.error('Room settings update failed:', e.message); return res.status(500).json({ error: 'Could not update room settings.' }); }
  });
});

// Room moderation and microphone-seat reservations (v11).
async function roomRole(roomId, userId) {
  const q = await pool.query(`SELECT r.owner_id, rm.role FROM rooms r LEFT JOIN room_moderators rm ON rm.room_id = r.id AND rm.user_id = $2 WHERE r.id = $1 AND r.is_active = TRUE`, [roomId, userId]);
  if (!q.rows[0]) return null;
  if (String(q.rows[0].owner_id) === String(userId)) return 'owner';
  return q.rows[0].role || 'member';
}

app.get('/api/rooms/:roomId/members', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room service is not configured on the server.' });
  return requireAuth(req, res, async () => {
    if (!/^\d{1,18}$/.test(String(req.params.roomId))) return res.status(400).json({ error: 'Invalid room ID.' });
    try {
      const role = await roomRole(req.params.roomId, req.user.id);
      if (!role) return res.status(404).json({ error: 'Room not found or inactive.' });
      const result = await pool.query(`SELECT u.id, u.display_name, m.joined_at, m.mic_seat, COALESCE(rm.role, 'member') AS role
        FROM room_members m JOIN users u ON u.id = m.user_id
        LEFT JOIN room_moderators rm ON rm.room_id = m.room_id AND rm.user_id = m.user_id
        WHERE m.room_id = $1 AND m.left_at IS NULL ORDER BY (m.mic_seat IS NULL), m.mic_seat, m.joined_at`, [req.params.roomId]);
      return res.json({ members: result.rows.map(m => ({ id: String(m.id), displayName: m.display_name, joinedAt: m.joined_at, micSeat: m.mic_seat, role: String(m.id) === String(req.user.id) && role === 'owner' ? 'owner' : m.role })) });
    } catch (e) { console.error('Room members failed:', e.message); return res.status(500).json({ error: 'Could not load room members.' }); }
  });
});

app.put('/api/rooms/:roomId/moderators/:userId', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room service is not configured on the server.' });
  return requireAuth(req, res, async () => {
    if (!/^\d{1,18}$/.test(String(req.params.roomId)) || !/^\d{1,18}$/.test(String(req.params.userId))) return res.status(400).json({ error: 'Invalid room or user ID.' });
    const action = req.body?.action;
    if (!['promote', 'remove'].includes(action)) return res.status(400).json({ error: "action must be 'promote' or 'remove'." });
    try {
      const role = await roomRole(req.params.roomId, req.user.id);
      if (role !== 'owner') return res.status(403).json({ error: 'Only the room owner can manage moderators.' });
      if (String(req.params.userId) === String(req.user.id)) return res.status(400).json({ error: 'The owner cannot be added as a moderator.' });
      if (action === 'promote') {
        const member = await pool.query('SELECT 1 FROM room_members WHERE room_id = $1 AND user_id = $2 AND left_at IS NULL', [req.params.roomId, req.params.userId]);
        if (!member.rowCount) return res.status(409).json({ error: 'User must be an active room member first.' });
        await pool.query(`INSERT INTO room_moderators (room_id, user_id, role) VALUES ($1, $2, 'moderator') ON CONFLICT (room_id, user_id) DO UPDATE SET role = 'moderator'`, [req.params.roomId, req.params.userId]);
      } else {
        await pool.query('DELETE FROM room_moderators WHERE room_id = $1 AND user_id = $2', [req.params.roomId, req.params.userId]);
      }
      return res.json({ ok: true, roomId: String(req.params.roomId), userId: String(req.params.userId), action });
    } catch (e) { console.error('Moderator management failed:', e.message); return res.status(500).json({ error: 'Could not update moderator.' }); }
  });
});

app.post('/api/rooms/:roomId/mic-seats/:seatNumber', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room service is not configured on the server.' });
  return requireAuth(req, res, async () => {
    if (!/^\d{1,18}$/.test(String(req.params.roomId)) || !/^\d{1,2}$/.test(String(req.params.seatNumber))) return res.status(400).json({ error: 'Invalid room or seat number.' });
    const targetUserId = String(req.body?.userId || req.user.id);
    if (!/^\d{1,18}$/.test(targetUserId)) return res.status(400).json({ error: 'Invalid userId.' });
    const seatNumber = Number(req.params.seatNumber);
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const roomQ = await client.query('SELECT id, owner_id, max_seats, mic_seat_limit, mic_seats_open FROM rooms WHERE id = $1 AND is_active = TRUE FOR UPDATE', [req.params.roomId]);
      const room = roomQ.rows[0];
      if (!room) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Room not found or inactive.' }); }
      const modQ = await client.query('SELECT role FROM room_moderators WHERE room_id = $1 AND user_id = $2', [room.id, req.user.id]);
      const isOwner = String(room.owner_id) === String(req.user.id);
      const isModerator = modQ.rows[0]?.role === 'moderator';
      if (targetUserId !== String(req.user.id) && !isOwner && !isModerator) { await client.query('ROLLBACK'); return res.status(403).json({ error: 'Only owner/moderator can assign another member.' }); }
      if (!room.mic_seats_open && !isOwner && !isModerator) { await client.query('ROLLBACK'); return res.status(403).json({ error: 'Microphone seats are currently closed.' }); }
      if (seatNumber < 1 || seatNumber > room.mic_seat_limit) { await client.query('ROLLBACK'); return res.status(400).json({ error: `Seat number must be between 1 and ${room.mic_seat_limit}.` }); }
      const memberQ = await client.query('SELECT 1 FROM room_members WHERE room_id = $1 AND user_id = $2 AND left_at IS NULL', [room.id, targetUserId]);
      if (!memberQ.rowCount) { await client.query('ROLLBACK'); return res.status(409).json({ error: 'User must be an active room member.' }); }
      const seatQ = await client.query('SELECT user_id FROM room_members WHERE room_id = $1 AND mic_seat = $2 AND left_at IS NULL AND user_id <> $3 FOR UPDATE', [room.id, seatNumber, targetUserId]);
      if (seatQ.rowCount) { await client.query('ROLLBACK'); return res.status(409).json({ error: 'That microphone seat is already occupied.' }); }
      await client.query('UPDATE room_members SET mic_seat = NULL WHERE room_id = $1 AND user_id = $2 AND left_at IS NULL', [room.id, targetUserId]);
      await client.query('UPDATE room_members SET mic_seat = $1 WHERE room_id = $2 AND user_id = $3 AND left_at IS NULL', [seatNumber, room.id, targetUserId]);
      await client.query('COMMIT');
      return res.json({ ok: true, roomId: String(room.id), userId: targetUserId, micSeat: seatNumber, note: 'A newly issued LiveKit token or reconnect may be required for publishing permissions to take effect.' });
    } catch (e) { await client.query('ROLLBACK').catch(() => {}); console.error('Mic seat assignment failed:', e.message); return res.status(500).json({ error: 'Could not assign microphone seat.' }); }
    finally { client.release(); }
  });
});

app.delete('/api/rooms/:roomId/mic-seats/:seatNumber', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room service is not configured on the server.' });
  return requireAuth(req, res, async () => {
    if (!/^\d{1,18}$/.test(String(req.params.roomId)) || !/^\d{1,2}$/.test(String(req.params.seatNumber))) return res.status(400).json({ error: 'Invalid room or seat number.' });
    try {
      const role = await roomRole(req.params.roomId, req.user.id);
      if (!['owner', 'moderator'].includes(role)) return res.status(403).json({ error: 'Only owner/moderator can clear microphone seats.' });
      const result = await pool.query('UPDATE room_members SET mic_seat = NULL WHERE room_id = $1 AND mic_seat = $2 AND left_at IS NULL RETURNING user_id', [req.params.roomId, Number(req.params.seatNumber)]);
      if (!result.rowCount) return res.status(404).json({ error: 'Microphone seat is already empty.' });
      return res.json({ ok: true, roomId: String(req.params.roomId), micSeat: Number(req.params.seatNumber), userId: String(result.rows[0].user_id) });
    } catch (e) { console.error('Mic seat clear failed:', e.message); return res.status(500).json({ error: 'Could not clear microphone seat.' }); }
  });
});

// Room chat and member moderation (v12).
const roomChatLimiter = rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });

app.get('/api/rooms/:roomId/messages', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room chat is not configured on the server.' });
  return requireAuth(req, res, async () => {
    if (!/^\d{1,18}$/.test(String(req.params.roomId))) return res.status(400).json({ error: 'Invalid room ID.' });
    try {
      const room = await pool.query('SELECT chat_enabled FROM rooms WHERE id = $1 AND is_active = TRUE', [req.params.roomId]);
      if (!room.rows[0]) return res.status(404).json({ error: 'Room not found or inactive.' });
      const member = await pool.query('SELECT 1 FROM room_members WHERE room_id = $1 AND user_id = $2 AND left_at IS NULL', [req.params.roomId, req.user.id]);
      if (!member.rowCount) return res.status(403).json({ error: 'Join this room to read its chat.' });
      if (!room.rows[0].chat_enabled) return res.status(403).json({ error: 'Chat is disabled in this room.' });
      const beforeId = req.query.beforeId === undefined ? null : String(req.query.beforeId);
      if (beforeId !== null && !/^\d{1,18}$/.test(beforeId)) return res.status(400).json({ error: 'Invalid beforeId.' });
      const result = await pool.query(`SELECT m.id, m.user_id, u.display_name, m.message, m.created_at
        FROM room_messages m JOIN users u ON u.id = m.user_id
        WHERE m.room_id = $1 AND ($2::bigint IS NULL OR m.id < $2::bigint)
        ORDER BY m.id DESC LIMIT 50`, [req.params.roomId, beforeId]);
      return res.json({ messages: result.rows.reverse().map(m => ({ id: String(m.id), userId: String(m.user_id), displayName: m.display_name, message: m.message, createdAt: m.created_at })) });
    } catch (e) { console.error('Room chat fetch failed:', e.message); return res.status(500).json({ error: 'Could not load room messages.' }); }
  });
});

app.post('/api/rooms/:roomId/messages', roomChatLimiter, async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room chat is not configured on the server.' });
  return requireAuth(req, res, async () => {
    if (!/^\d{1,18}$/.test(String(req.params.roomId))) return res.status(400).json({ error: 'Invalid room ID.' });
    const message = String(req.body?.message || '').trim();
    if (!message || message.length > 500) return res.status(400).json({ error: 'Message must be 1–500 characters.' });
    try {
      const room = await pool.query('SELECT chat_enabled FROM rooms WHERE id = $1 AND is_active = TRUE', [req.params.roomId]);
      if (!room.rows[0]) return res.status(404).json({ error: 'Room not found or inactive.' });
      if (!room.rows[0].chat_enabled) return res.status(403).json({ error: 'Chat is disabled in this room.' });
      const member = await pool.query('SELECT chat_muted FROM room_members WHERE room_id = $1 AND user_id = $2 AND left_at IS NULL ORDER BY joined_at DESC LIMIT 1', [req.params.roomId, req.user.id]);
      if (!member.rows[0]) return res.status(403).json({ error: 'Join this room to send messages.' });
      if (member.rows[0].chat_muted) return res.status(403).json({ error: 'Your chat permission is muted in this room.' });
      const result = await pool.query(`INSERT INTO room_messages (room_id, user_id, message) VALUES ($1, $2, $3)
        RETURNING id, user_id, message, created_at`, [req.params.roomId, req.user.id, message]);
      const m = result.rows[0];
      return res.status(201).json({ message: { id: String(m.id), userId: String(m.user_id), displayName: req.user.display_name, message: m.message, createdAt: m.created_at } });
    } catch (e) { console.error('Room chat send failed:', e.message); return res.status(500).json({ error: 'Could not send room message.' }); }
  });
});

app.patch('/api/rooms/:roomId/members/:userId/chat-permission', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room moderation is not configured on the server.' });
  return requireAuth(req, res, async () => {
    if (!/^\d{1,18}$/.test(String(req.params.roomId)) || !/^\d{1,18}$/.test(String(req.params.userId))) return res.status(400).json({ error: 'Invalid room or user ID.' });
    if (typeof req.body?.muted !== 'boolean') return res.status(400).json({ error: 'muted must be true or false.' });
    try {
      const actorRole = await roomRole(req.params.roomId, req.user.id);
      if (!['owner', 'moderator'].includes(actorRole)) return res.status(403).json({ error: 'Only owner/moderator can change chat permission.' });
      const targetRole = await roomRole(req.params.roomId, req.params.userId);
      if (!targetRole || targetRole === 'owner') return res.status(404).json({ error: 'Target member or room not found.' });
      if (actorRole === 'moderator' && targetRole === 'moderator') return res.status(403).json({ error: 'Moderators cannot change another moderator’s permission.' });
      const result = await pool.query(`UPDATE room_members SET chat_muted = $1 WHERE room_id = $2 AND user_id = $3 AND left_at IS NULL RETURNING user_id`, [req.body.muted, req.params.roomId, req.params.userId]);
      if (!result.rowCount) return res.status(404).json({ error: 'Target user is not an active room member.' });
      return res.json({ ok: true, roomId: String(req.params.roomId), userId: String(req.params.userId), chatMuted: req.body.muted });
    } catch (e) { console.error('Chat permission update failed:', e.message); return res.status(500).json({ error: 'Could not update chat permission.' }); }
  });
});

app.post('/api/rooms/:roomId/members/:userId/remove', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Room moderation is not configured on the server.' });
  return requireAuth(req, res, async () => {
    if (!/^\d{1,18}$/.test(String(req.params.roomId)) || !/^\d{1,18}$/.test(String(req.params.userId))) return res.status(400).json({ error: 'Invalid room or user ID.' });
    if (String(req.params.userId) === String(req.user.id)) return res.status(400).json({ error: 'Use the leave-room endpoint to leave yourself.' });
    try {
      const actorRole = await roomRole(req.params.roomId, req.user.id);
      if (!['owner', 'moderator'].includes(actorRole)) return res.status(403).json({ error: 'Only owner/moderator can remove room members.' });
      const targetRole = await roomRole(req.params.roomId, req.params.userId);
      if (!targetRole || targetRole === 'owner') return res.status(404).json({ error: 'Target member or room not found.' });
      if (actorRole === 'moderator' && targetRole === 'moderator') return res.status(403).json({ error: 'Moderators cannot remove another moderator.' });
      const result = await pool.query(`UPDATE room_members SET left_at = NOW(), mic_seat = NULL, chat_muted = FALSE
        WHERE room_id = $1 AND user_id = $2 AND left_at IS NULL RETURNING user_id`, [req.params.roomId, req.params.userId]);
      if (!result.rowCount) return res.status(404).json({ error: 'Target user is not an active room member.' });
      return res.json({ ok: true, roomId: String(req.params.roomId), userId: String(req.params.userId), removed: true, note: 'This removes database membership and frees the seat. Disconnecting an already-connected LiveKit participant requires the LiveKit server-side room service.' });
    } catch (e) { console.error('Room member removal failed:', e.message); return res.status(500).json({ error: 'Could not remove room member.' }); }
  });
});

// Private messages and inbox (v14). Requires migration 014_private_messages.sql.
const privateMessageLimiter = rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });

app.get('/api/messages/conversations', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Messaging is not configured on the server.' });
  return requireAuth(req, res, async () => {
    try {
      const result = await pool.query(`
        SELECT DISTINCT ON (other_user.id)
          other_user.id AS user_id, other_user.display_name,
          m.id AS message_id, m.sender_id, m.recipient_id, m.body, m.created_at,
          (SELECT COUNT(*) FROM direct_messages unread
            WHERE unread.sender_id = other_user.id AND unread.recipient_id = $1 AND unread.read_at IS NULL) AS unread_count
        FROM direct_messages m
        JOIN users other_user ON other_user.id = CASE WHEN m.sender_id = $1 THEN m.recipient_id ELSE m.sender_id END
        WHERE m.sender_id = $1 OR m.recipient_id = $1
        ORDER BY other_user.id, m.created_at DESC, m.id DESC`, [req.user.id]);
      const conversations = result.rows.map(r => ({ userId: String(r.user_id), displayName: r.display_name, lastMessage: r.body, lastMessageAt: r.created_at, lastMessageFromMe: String(r.sender_id) === String(req.user.id), unreadCount: Number(r.unread_count) }));
      conversations.sort((a,b) => new Date(b.lastMessageAt) - new Date(a.lastMessageAt));
      return res.json({ conversations });
    } catch (e) { console.error('Inbox fetch failed:', e.message); return res.status(500).json({ error: 'Could not load inbox.' }); }
  });
});

app.get('/api/messages/:userId', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Messaging is not configured on the server.' });
  return requireAuth(req, res, async () => {
    const otherId = String(req.params.userId);
    if (!/^\d{1,18}$/.test(otherId) || otherId === String(req.user.id)) return res.status(400).json({ error: 'Enter a valid conversation user ID.' });
    try {
      const exists = await pool.query('SELECT id FROM users WHERE id = $1', [otherId]);
      if (!exists.rowCount) return res.status(404).json({ error: 'User not found.' });
      const result = await pool.query(`SELECT m.id, m.sender_id, m.recipient_id, m.body, m.created_at, m.read_at, u.display_name AS sender_name
        FROM direct_messages m JOIN users u ON u.id = m.sender_id
        WHERE (m.sender_id = $1 AND m.recipient_id = $2) OR (m.sender_id = $2 AND m.recipient_id = $1)
        ORDER BY m.id DESC LIMIT 100`, [req.user.id, otherId]);
      await pool.query('UPDATE direct_messages SET read_at = NOW() WHERE sender_id = $1 AND recipient_id = $2 AND read_at IS NULL', [otherId, req.user.id]);
      return res.json({ messages: result.rows.reverse().map(m => ({ id: String(m.id), senderId: String(m.sender_id), recipientId: String(m.recipient_id), senderName: m.sender_name, body: m.body, createdAt: m.created_at, readAt: m.read_at })) });
    } catch (e) { console.error('Conversation fetch failed:', e.message); return res.status(500).json({ error: 'Could not load conversation.' }); }
  });
});

app.post('/api/messages/:userId', privateMessageLimiter, async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Messaging is not configured on the server.' });
  return requireAuth(req, res, async () => {
    const otherId = String(req.params.userId);
    const body = String(req.body?.message || '').trim();
    if (!/^\d{1,18}$/.test(otherId) || otherId === String(req.user.id)) return res.status(400).json({ error: 'Enter a valid recipient user ID.' });
    if (!body || body.length > 1000) return res.status(400).json({ error: 'Message must be 1–1000 characters.' });
    try {
      const recipient = await pool.query('SELECT id, display_name FROM users WHERE id = $1', [otherId]);
      if (!recipient.rowCount) return res.status(404).json({ error: 'Recipient not found.' });
      const result = await pool.query(`INSERT INTO direct_messages (sender_id, recipient_id, body)
        VALUES ($1, $2, $3) RETURNING id, sender_id, recipient_id, body, created_at, read_at`, [req.user.id, otherId, body]);
      const m = result.rows[0];
      return res.status(201).json({ message: { id: String(m.id), senderId: String(m.sender_id), recipientId: String(m.recipient_id), senderName: req.user.display_name, body: m.body, createdAt: m.created_at, readAt: m.read_at }, recipient: { id: String(recipient.rows[0].id), displayName: recipient.rows[0].display_name } });
    } catch (e) { console.error('Private message send failed:', e.message); return res.status(500).json({ error: 'Could not send private message.' }); }
  });
});

app.get('/api/wallet', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Wallet is not configured on the server.' });
  return requireAuth(req, res, async () => {
    try {
      await pool.query('INSERT INTO wallets (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING', [req.user.id]);
      const result = await pool.query('SELECT coins, diamonds, cash_usd, updated_at FROM wallets WHERE user_id = $1', [req.user.id]);
      const w = result.rows[0];
      return res.json({ wallet: { coins: Number(w.coins), diamonds: Number(w.diamonds), cashUsd: Number(w.cash_usd), updatedAt: w.updated_at, currency: 'USD' }, note: 'Balances are server-controlled. Cash withdrawals and purchases are not enabled in this prototype.' });
    } catch (e) { console.error('Wallet read failed:', e.message); return res.status(500).json({ error: 'Could not load wallet.' }); }
  });
});

app.get('/api/wallet/transactions', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Wallet is not configured on the server.' });
  return requireAuth(req, res, async () => {
    try {
      const result = await pool.query('SELECT id, entry_type, asset, amount, status, description, created_at FROM wallet_transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50', [req.user.id]);
      return res.json({ transactions: result.rows.map(t => ({ id: t.id, type: t.entry_type, asset: t.asset, amount: Number(t.amount), status: t.status, description: t.description, createdAt: t.created_at })) });
    } catch (e) { console.error('Wallet transactions failed:', e.message); return res.status(500).json({ error: 'Could not load wallet history.' }); }
  });
});

const GIFT_CATALOG = Object.freeze([
  { id: 'rose', name: 'Rose', emoji: '🌹', diamondCost: 10, receiverCoins: 5 },
  { id: 'heart', name: 'Heart', emoji: '💖', diamondCost: 50, receiverCoins: 25 },
  { id: 'crown', name: 'Crown', emoji: '👑', diamondCost: 200, receiverCoins: 100 },
  { id: 'rocket', name: 'Rocket', emoji: '🚀', diamondCost: 1000, receiverCoins: 500 }
]);

app.get('/api/gifts/catalog', (_req, res) => res.json({ gifts: GIFT_CATALOG }));

app.post('/api/gifts/send', rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false }), async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Gift service is not configured on the server.' });
  return requireAuth(req, res, async () => {
    const giftId = String(req.body?.giftId || '');
    const recipientId = String(req.body?.recipientId || '').trim();
    const gift = GIFT_CATALOG.find(item => item.id === giftId);
    if (!gift) return res.status(400).json({ error: 'Choose a valid gift from the catalog.' });
    if (!/^\d{1,18}$/.test(recipientId) || recipientId === String(req.user.id)) return res.status(400).json({ error: 'Enter another valid user ID.' });

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const users = await client.query('SELECT id, display_name FROM users WHERE id = $1', [recipientId]);
      if (!users.rows[0]) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: 'Recipient account was not found.' });
      }
      // Always lock wallets in ascending ID order to reduce deadlock risk.
      await client.query('INSERT INTO wallets (user_id) VALUES ($1), ($2) ON CONFLICT (user_id) DO NOTHING', [req.user.id, recipientId]);
      await client.query('SELECT user_id FROM wallets WHERE user_id = ANY($1::bigint[]) ORDER BY user_id FOR UPDATE', [[String(req.user.id), recipientId].sort((a,b) => BigInt(a) < BigInt(b) ? -1 : BigInt(a) > BigInt(b) ? 1 : 0)]);
      const senderResult = await client.query('SELECT diamonds FROM wallets WHERE user_id = $1', [req.user.id]);
      const senderDiamonds = BigInt(senderResult.rows[0].diamonds);
      if (senderDiamonds < BigInt(gift.diamondCost)) {
        await client.query('ROLLBACK');
        return res.status(409).json({ error: `Not enough diamonds. This gift costs ${gift.diamondCost} diamonds.` });
      }
      await client.query('UPDATE wallets SET diamonds = diamonds - $1, updated_at = NOW() WHERE user_id = $2', [gift.diamondCost, req.user.id]);
      await client.query('UPDATE wallets SET coins = coins + $1, updated_at = NOW() WHERE user_id = $2', [gift.receiverCoins, recipientId]);
      await client.query(`INSERT INTO wallet_transactions (user_id, entry_type, asset, amount, status, description)
        VALUES ($1, 'gift', 'diamonds', $2, 'completed', $3), ($4, 'gift', 'coins', $5, 'completed', $6)`,
        [req.user.id, gift.diamondCost, `Sent ${gift.name} to user #${recipientId}`, recipientId, gift.receiverCoins, `Received ${gift.name} from user #${req.user.id}`]);
      const updated = await client.query('SELECT coins, diamonds, cash_usd FROM wallets WHERE user_id = $1', [req.user.id]);
      await client.query('COMMIT');
      return res.status(201).json({
        sent: { giftId: gift.id, giftName: gift.name, recipientId, recipientName: users.rows[0].display_name, diamondsSpent: gift.diamondCost, recipientCoinsAwarded: gift.receiverCoins },
        wallet: { coins: Number(updated.rows[0].coins), diamonds: Number(updated.rows[0].diamonds), cashUsd: Number(updated.rows[0].cash_usd), currency: 'USD' }
      });
    } catch (e) {
      await client.query('ROLLBACK').catch(() => {});
      console.error('Gift send failed:', e.message);
      return res.status(500).json({ error: 'Could not send gift. No balance change was committed.' });
    } finally { client.release(); }
  });
});

app.post('/api/livekit-token', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Server authentication is not configured.' });
  return requireAuth(req, res, async () => {
    try {
      if (!process.env.LIVEKIT_API_KEY || !process.env.LIVEKIT_API_SECRET || !process.env.LIVEKIT_URL) return res.status(503).json({ error: 'LiveKit credentials are not configured.' });
      const room = String(req.body?.room || '').trim();
      if (!/^[a-zA-Z0-9_-]{1,80}$/.test(room)) return res.status(400).json({ error: 'A valid room name is required.' });
      const token = new AccessToken(process.env.LIVEKIT_API_KEY, process.env.LIVEKIT_API_SECRET, { identity: String(req.user.id), ttl: '1h' });
      token.addGrant({ roomJoin: true, room, canPublish: true, canSubscribe: true });
      res.json({ token: await token.toJwt(), url: process.env.LIVEKIT_URL });
    } catch (e) { console.error('LiveKit token failed:', e.message); res.status(500).json({ error: 'Could not create room token.' }); }
  });
});



// Community, notifications, daily rewards, referrals and admin overview (v18).
const adminUserIds = new Set(String(process.env.ADMIN_USER_IDS || '').split(',').map(v => v.trim()).filter(v => /^\d{1,18}$/.test(v)));
function adminRequired(req, res, next) {
  if (!adminUserIds.has(String(req.user?.id))) return res.status(403).json({ error: 'Admin access required. Configure ADMIN_USER_IDS on the server.' });
  next();
}

app.get('/api/users/search', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'User search is not configured.' });
  return requireAuth(req, res, async () => {
    const q = String(req.query.q || '').trim().slice(0, 50);
    if (q.length < 2) return res.json({ users: [] });
    try {
      const result = await pool.query(`SELECT u.id, u.display_name,
        (SELECT COUNT(*)::int FROM user_follows f WHERE f.followed_id=u.id) AS followers,
        EXISTS(SELECT 1 FROM user_follows f WHERE f.follower_id=$2 AND f.followed_id=u.id) AS following
        FROM users u WHERE u.id::text = $1 OR u.display_name ILIKE $3
        ORDER BY u.display_name LIMIT 30`, [q, req.user.id, `%${q}%`]);
      return res.json({ users: result.rows.map(u => ({ id: String(u.id), displayName: u.display_name, followers: u.followers, following: u.following })) });
    } catch (e) { console.error('User search failed:', e.message); return res.status(500).json({ error: 'Could not search users.' }); }
  });
});

app.post('/api/users/:userId/follow', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Follow service is not configured.' });
  return requireAuth(req, res, async () => {
    const target = String(req.params.userId);
    if (!/^\d{1,18}$/.test(target) || target === String(req.user.id)) return res.status(400).json({ error: 'Choose another valid user.' });
    const action = String(req.body?.action || 'follow');
    if (!['follow','unfollow'].includes(action)) return res.status(400).json({ error: 'Action must be follow or unfollow.' });
    try {
      const exists = await pool.query('SELECT id FROM users WHERE id=$1', [target]);
      if (!exists.rowCount) return res.status(404).json({ error: 'User not found.' });
      if (action === 'follow') {
        const r = await pool.query('INSERT INTO user_follows (follower_id, followed_id) VALUES ($1,$2) ON CONFLICT DO NOTHING RETURNING follower_id', [req.user.id, target]);
        if (r.rowCount) await pool.query(`INSERT INTO notifications(user_id,kind,title,body,payload) VALUES($1,'new_follower','New follower',$2,$3)`, [target, `${req.user.display_name} started following you.`, JSON.stringify({ userId: String(req.user.id) })]);
      } else await pool.query('DELETE FROM user_follows WHERE follower_id=$1 AND followed_id=$2', [req.user.id, target]);
      const count = await pool.query('SELECT COUNT(*)::int AS n FROM user_follows WHERE followed_id=$1', [target]);
      return res.json({ ok: true, following: action === 'follow', followers: count.rows[0].n });
    } catch (e) { console.error('Follow action failed:', e.message); return res.status(500).json({ error: 'Could not update follow status.' }); }
  });
});

app.get('/api/users/:userId/profile', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Profiles are not configured.' });
  return requireAuth(req, res, async () => {
    const target = String(req.params.userId);
    if (!/^\d{1,18}$/.test(target)) return res.status(400).json({ error: 'Invalid user ID.' });
    try {
      const r = await pool.query(`SELECT u.id,u.display_name,u.created_at,
        (SELECT COUNT(*)::int FROM user_follows f WHERE f.followed_id=u.id) AS followers,
        (SELECT COUNT(*)::int FROM user_follows f WHERE f.follower_id=u.id) AS following,
        EXISTS(SELECT 1 FROM user_follows f WHERE f.follower_id=$2 AND f.followed_id=u.id) AS is_following
        FROM users u WHERE u.id=$1`, [target, req.user.id]);
      if (!r.rowCount) return res.status(404).json({ error: 'User not found.' });
      const u = r.rows[0];
      return res.json({ profile: { id: String(u.id), displayName: u.display_name, createdAt: u.created_at, followers: u.followers, following: u.following, isFollowing: u.is_following } });
    } catch (e) { console.error('Profile fetch failed:', e.message); return res.status(500).json({ error: 'Could not load profile.' }); }
  });
});

app.get('/api/leaderboard', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Leaderboard is not configured.' });
  return requireAuth(req, res, async (_req, res2) => {
    try {
      const result = await pool.query(`SELECT u.id,u.display_name,COALESCE(w.coins,0)::text AS coins,
        (SELECT COUNT(*) FROM user_follows f WHERE f.followed_id=u.id)::int AS followers
        FROM users u LEFT JOIN wallets w ON w.user_id=u.id ORDER BY followers DESC, u.created_at ASC LIMIT 50`);
      return res2.json({ leaderboard: result.rows.map((u,i)=>({ rank:i+1,userId:String(u.id),displayName:u.display_name,followers:u.followers,coins:Number(u.coins) })) });
    } catch (e) { console.error('Leaderboard failed:', e.message); return res2.status(500).json({ error: 'Could not load leaderboard.' }); }
  });
});

app.get('/api/notifications', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Notifications are not configured.' });
  return requireAuth(req, res, async (_req, res2) => {
    try {
      const result = await pool.query('SELECT id,kind,title,body,payload,read_at,created_at FROM notifications WHERE user_id=$1 ORDER BY id DESC LIMIT 100', [req.user.id]);
      const unread = await pool.query('SELECT COUNT(*)::int AS n FROM notifications WHERE user_id=$1 AND read_at IS NULL', [req.user.id]);
      return res2.json({ notifications: result.rows.map(n=>({ id:String(n.id),kind:n.kind,title:n.title,body:n.body,payload:n.payload,readAt:n.read_at,createdAt:n.created_at })), unreadCount: unread.rows[0].n });
    } catch (e) { console.error('Notifications fetch failed:', e.message); return res2.status(500).json({ error: 'Could not load notifications.' }); }
  });
});

app.post('/api/notifications/:notificationId/read', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Notifications are not configured.' });
  return requireAuth(req, res, async (_req, res2) => {
    if (!/^\d{1,18}$/.test(String(req.params.notificationId))) return res2.status(400).json({ error: 'Invalid notification ID.' });
    try { const r=await pool.query('UPDATE notifications SET read_at=COALESCE(read_at,NOW()) WHERE id=$1 AND user_id=$2 RETURNING id', [req.params.notificationId,req.user.id]); return r.rowCount?res2.json({ok:true}):res2.status(404).json({error:'Notification not found.'}); }
    catch(e){ console.error('Notification read failed:',e.message); return res2.status(500).json({error:'Could not update notification.'}); }
  });
});

app.post('/api/rewards/daily/claim', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Daily rewards are not configured.' });
  return requireAuth(req, res, async (_req, res2) => {
    const rewardCoins = Math.max(0, Math.min(100000, Number(process.env.DAILY_REWARD_COINS || 300)));
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const claim = await client.query('INSERT INTO daily_reward_claims(user_id,reward_date,coins) VALUES($1,CURRENT_DATE,$2) ON CONFLICT DO NOTHING RETURNING coins', [req.user.id,rewardCoins]);
      if (!claim.rowCount) { await client.query('ROLLBACK'); return res2.status(409).json({error:'Daily reward already claimed today.'}); }
      await client.query('INSERT INTO wallets(user_id) VALUES($1) ON CONFLICT DO NOTHING',[req.user.id]);
      await client.query('UPDATE wallets SET coins=coins+$1,updated_at=NOW() WHERE user_id=$2',[rewardCoins,req.user.id]);
      await client.query(`INSERT INTO wallet_transactions(user_id,entry_type,asset,amount,status,description) VALUES($1,'daily_reward','coins',$2,'completed','Daily sign-in reward')`,[req.user.id,rewardCoins]);
      await client.query(`INSERT INTO notifications(user_id,kind,title,body) VALUES($1,'daily_reward','Daily reward claimed',$2)`,[req.user.id,`${rewardCoins} coins were added to your wallet.`]);
      const wallet=await client.query('SELECT coins,diamonds,cash_usd FROM wallets WHERE user_id=$1',[req.user.id]);
      await client.query('COMMIT');
      return res2.json({ok:true,rewardCoins,wallet:{coins:Number(wallet.rows[0].coins),diamonds:Number(wallet.rows[0].diamonds),cashUsd:Number(wallet.rows[0].cash_usd)}});
    } catch(e){await client.query('ROLLBACK').catch(()=>{});console.error('Daily reward failed:',e.message);return res2.status(500).json({error:'Could not claim daily reward.'});} finally{client.release();}
  });
});

app.post('/api/referrals', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Referrals are not configured.' });
  return requireAuth(req, res, async (_req, res2) => {
    const referredId=String(req.body?.referredUserId||'');
    if(!/^\d{1,18}$/.test(referredId)||referredId===String(req.user.id))return res2.status(400).json({error:'Enter a valid referred user ID.'});
    try{const u=await pool.query('SELECT id FROM users WHERE id=$1',[referredId]);if(!u.rowCount)return res2.status(404).json({error:'Referred user not found.'});
      await pool.query('INSERT INTO referrals(referrer_id,referred_id) VALUES($1,$2) ON CONFLICT(referred_id) DO NOTHING',[req.user.id,referredId]);
      const r=await pool.query('SELECT COUNT(*)::int AS total FROM referrals WHERE referrer_id=$1',[req.user.id]);return res2.json({ok:true,referrals:r.rows[0].total,note:'Referral rewards require fraud checks and server-side qualification before payout.'});
    }catch(e){if(e.code==='23505')return res2.status(409).json({error:'This user already has a referral recorded.'});console.error('Referral record failed:',e.message);return res2.status(500).json({error:'Could not record referral.'});}
  });
});

app.post('/api/reports', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Reports are not configured.' });
  return requireAuth(req, res, async (_req, res2) => {
    const targetUserId=req.body?.targetUserId==null?null:String(req.body.targetUserId);
    const roomId=req.body?.roomId==null?null:String(req.body.roomId);
    const reason=String(req.body?.reason||'').trim(); const details=String(req.body?.details||'').trim();
    if(!['harassment','spam','fraud','inappropriate_content','other'].includes(reason))return res2.status(400).json({error:'Choose a valid report reason.'});
    if(details.length>1000)return res2.status(400).json({error:'Details must be 1,000 characters or fewer.'});
    if(targetUserId!==null&&!/^\d{1,18}$/.test(targetUserId))return res2.status(400).json({error:'Invalid target user ID.'});
    if(roomId!==null&&!/^\d{1,18}$/.test(roomId))return res2.status(400).json({error:'Invalid room ID.'});
    try{const r=await pool.query('INSERT INTO user_reports(reporter_id,target_user_id,room_id,reason,details) VALUES($1,$2,$3,$4,$5) RETURNING id,created_at',[req.user.id,targetUserId,roomId,reason,details]);return res2.status(201).json({ok:true,report:{id:String(r.rows[0].id),createdAt:r.rows[0].created_at}});}
    catch(e){console.error('Report create failed:',e.message);return res2.status(500).json({error:'Could not submit report.'});}
  });
});

app.get('/api/admin/overview', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Admin API is not configured.' });
  return requireAuth(req, res, async (_req, res2, next) => {
    adminRequired(req,res2,async()=>{
      try{const [users,rooms,reports,wallets]=await Promise.all([
        pool.query('SELECT COUNT(*)::int AS n FROM users'),pool.query('SELECT COUNT(*)::int AS n FROM rooms WHERE is_active=TRUE'),pool.query("SELECT COUNT(*)::int AS n FROM user_reports WHERE status='open'"),pool.query('SELECT COALESCE(SUM(cash_usd),0)::numeric(14,2) AS total FROM wallets')]);
        return res2.json({users:users.rows[0].n,activeRooms:rooms.rows[0].n,openReports:reports.rows[0].n,walletCashUsd:Number(wallets.rows[0].total),note:'Overview only; payout and payment operations are deliberately not enabled.'});
      }catch(e){console.error('Admin overview failed:',e.message);return res2.status(500).json({error:'Could not load admin overview.'});}
    });
  });
});

app.get('/api/admin/reports', async (req, res) => {
  if (!dbReady()) return res.status(503).json({ error: 'Admin API is not configured.' });
  return requireAuth(req,res,async()=>{ if(!adminUserIds.has(String(req.user.id)))return res.status(403).json({error:'Admin access required.'});
    try{const r=await pool.query(`SELECT r.id,r.reason,r.details,r.status,r.created_at,reporter.display_name AS reporter_name,
      target.display_name AS target_name,r.room_id FROM user_reports r JOIN users reporter ON reporter.id=r.reporter_id LEFT JOIN users target ON target.id=r.target_user_id ORDER BY r.created_at DESC LIMIT 100`);
      return res.json({reports:r.rows.map(x=>({...x,id:String(x.id),roomId:x.room_id==null?null:String(x.room_id)}))});
    }catch(e){console.error('Admin reports failed:',e.message);return res.status(500).json({error:'Could not load reports.'});}
  });
});

app.patch('/api/admin/reports/:reportId', async (req,res)=>{
  if(!dbReady())return res.status(503).json({error:'Admin API is not configured.'});
  return requireAuth(req,res,async()=>{if(!adminUserIds.has(String(req.user.id)))return res.status(403).json({error:'Admin access required.'});
    if(!/^\d{1,18}$/.test(String(req.params.reportId))||!['reviewing','resolved','dismissed'].includes(req.body?.status))return res.status(400).json({error:'Invalid report ID or status.'});
    try{const r=await pool.query('UPDATE user_reports SET status=$1,reviewed_at=NOW() WHERE id=$2 RETURNING id,status',[req.body.status,req.params.reportId]);return r.rowCount?res.json({ok:true,report:{id:String(r.rows[0].id),status:r.rows[0].status}}):res.status(404).json({error:'Report not found.'});}
    catch(e){console.error('Admin report update failed:',e.message);return res.status(500).json({error:'Could not update report.'});}
  });
});

app.use((err, _req, res, _next) => { console.error('Unhandled request error:', err.message); res.status(500).json({ error: 'Unexpected server error.' }); });
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`JUMANJI LIVE API listening on port ${port}`));
