# JUMANJI LIVE COMPLETE v28

This ZIP is arranged with one project folder (no duplicate nested package folder):
- `JUMANJI_LIVE_Android/` — Android Studio project and backend source
- `SETUP_GUIDE_BN.md` — setup instructions in Bengali
- `FEATURES_AND_STATUS.md` — feature and limitation status
- `ANDROID_BUILD_STATUS.md` — build status

## Android APK
Open `JUMANJI_LIVE_Android/` in Android Studio, sync Gradle, then choose **Build > Build APK(s)**. Alternatively, upload the contents of `JUMANJI_LIVE_Android/` to the root of a GitHub repository and run the included GitHub Actions workflow.

This is source code, not a prebuilt APK. Static checks passing do not prove a successful Android build or working live services. Database, LiveKit, payment, sign-in providers, and real-device testing still require setup and validation. Never commit `.env` or API secrets.


### v29 update
The app now prioritizes the backend API URL saved in Settings after a restart, avoiding the default emulator URL overriding a deployed backend address. Android version: 0.3.1. APK generation and real-device testing are still required.
