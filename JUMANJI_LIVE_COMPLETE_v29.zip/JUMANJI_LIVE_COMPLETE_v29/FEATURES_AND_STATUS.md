# JUMANJI LIVE — Feature and Verification Status (v27)

## Included source
- Android WebView shell and bundled English UI
- Backend API and PostgreSQL schema/migrations
- Email/password auth, rooms/chat, wallet ledger, LiveKit token endpoint, notifications, reports/referrals and admin API foundations
- API URL settings, API health test, GitHub Actions debug-build workflow
- v27: WebViewAssetLoader secure local asset origin and microphone permission lifecycle handling

## Not verified / not production-ready
- No compiled APK is included; GitHub Actions has not been run for this package
- No physical-device or LiveKit audio test has been run
- Database integration tests require a configured PostgreSQL service
- Google/Facebook/phone OTP sign-in, bKash integration, real cash withdrawal, push notifications, and several games/room moderation integrations are incomplete or demo-only
- Wallet coin values are not real money and referral entries do not guarantee payouts


## v29 update
- Fixed API URL selection precedence: a previously saved backend URL is used after app restart instead of the default Android emulator URL overriding it.
- Android app version bumped to 0.3.1 (versionCode 4).
- Static checks do not prove a successful APK build or live backend/device operation.
