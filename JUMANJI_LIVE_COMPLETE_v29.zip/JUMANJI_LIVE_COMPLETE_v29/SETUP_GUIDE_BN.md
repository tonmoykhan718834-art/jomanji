# JUMANJI LIVE v27 — বাংলা সেটআপ গাইড

## Android APK build
1. ZIP Extract করো।
2. `JUMANJI_LIVE_Android` ফোল্ডারটি Android Studio-তে খোলো।
3. Internet চালু রেখে Gradle Sync শেষ করো; v27-তে `androidx.webkit:webkit:1.12.1` dependency আছে।
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)** নির্বাচন করো।
5. সফল হলে `app/build/outputs/apk/debug/app-debug.apk` ফাইলটি পাওয়া যাবে।

GitHub দিয়ে build করতে `JUMANJI_LIVE_Android` ফোল্ডারের ভেতরের ফাইলগুলো repository-র root-এ আপলোড করো। এরপর **Actions → JUMANJI LIVE Android build → Run workflow** চালাও। সফল হলে workflow run-এর **Artifacts** থেকে `jumanji-live-debug-apk` নাও। Workflow এখনো চালানো না হলে APK তৈরি হয়েছে ধরে নিও না।

## Backend setup
1. `.env.example` কপি করে `.env` বানাও; database URL ও JWT secret-এর sample value বদলাও।
2. `docker compose up --build -d` চালাও (Docker ইনস্টল থাকতে হবে)।
3. `/health` endpoint পরীক্ষা করো।
4. `npm run test:static` চালাও। Smoke test চালাতে PostgreSQL ও backend সঠিকভাবে configured এবং reachable হতে হবে।

## নিরাপত্তা ও সীমাবদ্ধতা
- v27-এর HTML AndroidX WebViewAssetLoader দিয়ে secure appassets HTTPS origin-এ লোড হয়; microphone ব্যবহারে Android permission দিতে হবে। তবুও LiveKit voice বাস্তব ফোনে পরীক্ষা করা প্রয়োজন।
- `.env`, database password, JWT secret, LiveKit secret বা signing key কখনো Android app/GitHub code-এ রেখো না। আগে কোনো secret শেয়ার করে থাকলে সেটি rotate করো।
- Google/Facebook/Phone OTP login, bKash, real cash withdrawal এবং সব room/game feature সম্পূর্ণ production integration নয়। Wallet coins বাস্তব টাকা নয়।


### v29 update
The app now prioritizes the backend API URL saved in Settings after a restart, avoiding the default emulator URL overriding a deployed backend address. Android version: 0.3.1. APK generation and real-device testing are still required.
